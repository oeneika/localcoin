<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8" />
    <title><?php echo e(config('app.name')); ?></title>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <!-- ================== BEGIN BASE CSS STYLE ================== -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
    <link href="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('plugins/bootstrap/4.1.0/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
    <link href="<?php echo e(asset('plugins/toastr/toastr.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('plugins/animate/animate.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/default/style.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/default/style-responsive.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/default/theme/default.css')); ?>" rel="stylesheet" id="theme" />
    <!-- ================== END BASE CSS STYLE ================== -->
    
    <!-- ================== BEGIN PAGE LEVEL STYLE ================== -->
    <link href="<?php echo e(asset('plugins/jquery-jvectormap/jquery-jvectormap.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('plugins/bootstrap-datepicker/css/bootstrap-datepicker.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('plugins/bootstrap-datepicker/css/bootstrap-datepicker3.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('plugins/gritter/css/jquery.gritter.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('plugins/star-rating/dist/star-rating.css')); ?>" rel="stylesheet" />


    <link href="<?php echo e(asset('css/estilos.css')); ?>" rel="stylesheet" />
    <!-- ================== END PAGE LEVEL STYLE ================== -->

    <?php echo $__env->yieldContent('header_section'); ?>
    
    <!-- ================== BEGIN BASE JS ================== -->
    <script src="<?php echo e(asset('plugins/pace/pace.min.js')); ?>"></script>
    <!-- ================== END BASE JS ================== -->
</head>

<body>
        <!-- begin #page-container -->
        <div id="page-container" class="fade page-sidebar-fixed page-header-fixed">
            <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('inc.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->yieldContent('layouts.scroll'); ?>
        </div>
        <!-- end page container -->
        

    <!-- common libraries. required for every page-->
    <script src="<?php echo e(asset('plugins/jquery/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/bootstrap/4.1.0/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/js-cookie/js.cookie.js')); ?>"></script>
    <script src="<?php echo e(asset('js/theme/default.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/toastr/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/apps.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/php.js')); ?>"></script>
    <script src="<?php echo e(asset('js/delete_item.js')); ?>"></script>
    <!-- ================== END BASE JS ================== -->
    
    <!-- ================== BEGIN PAGE LEVEL JS ================== -->
    <script src="<?php echo e(asset('plugins/bootstrap-datepicker/js/bootstrap-datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/star-rating/dist/star-rating.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/gritter/js/jquery.gritter.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/bootstrap-sweetalert/sweetalert.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/demo/ui-modal-notification.demo.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/flot/jquery.flot.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/flot/jquery.flot.time.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/flot/jquery.flot.resize.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/flot/jquery.flot.pie.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/sparkline/jquery.sparkline.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/jquery-jvectormap/jquery-jvectormap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/jquery-jvectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/bootstrap-datepicker/js/bootstrap-datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/chart-js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/demo/dashboard.min.js')); ?>"></script>

    <!-- ================== END PAGE LEVEL JS ================== -->


    <!-- Page specific scripts -->
    <?php echo $__env->yieldContent('footer_section'); ?>
    
    <script>
        $(document).ready(function() {
            App.init();
            ChartJs.init();
            Dashboard.init();
            Notification.init();
        });
    </script>

    <?php echo $__env->make('inc.toastrmessages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- important routes -->
    <script>
            var url = {
                    storeSell:              '<?php echo e(route('storeSell')); ?>',
                    storeBuy:               '<?php echo e(route('storeBuy')); ?>',
                    updateBuy:              '<?php echo e(route('updateBuy')); ?>',
                    updateSell:             '<?php echo e(route('updateSell')); ?>',
                    makeTransaction:        '<?php echo e(route('makeTransaction')); ?>',
                    storeBankAccount:       '<?php echo e(route('storeBankAccount')); ?>',
                    rankUser:               '<?php echo e(route('rankUser')); ?>',
                    storeWallet:            '<?php echo e(route('storeWallet')); ?>'}
    </script>
        
</body>
</html>
