<?php $__env->startSection('content'); ?>
        <!-- begin #content -->
        <div id="content" class="content">
            <!-- begin breadcrumb -->
            <ol class="breadcrumb pull-right">
                <li class="breadcrumb-item"><a href="javascript:;">Home</a></li>
                <li class="breadcrumb-item active">Perfil de usuario</li>
            </ol>
            <!-- end breadcrumb -->
            <!-- begin page-header -->
            <h1 class="page-header">Perfil de usuario</h1>
            <!-- end page-header -->
            
            <div class="row">
                <div class="col-md-7">
                    <!-- begin panel -->
                    <div class="panel panel-inverse">
                        <div class="panel-heading">
                            
                            <h4 class="panel-title">Perfil de usuario</h4>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h3 class="mt-sm mb-xs"></h3>                                               
                                                <p><strong>Nombre y Apellido: </strong><?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastname); ?></p>
                                                <p><strong>E-mail: </strong><a href="mailto:#"> <?php echo e(Auth::user()->email); ?></a></p>
                                                <p><strong>Usuario: </strong><?php echo e(Auth::user()->user); ?></p>  
                                                <hr> 
                                                <p><strong>Teléfono Local: </strong> <?php echo e(Auth::user()->phone); ?></p> 
                                                <p><strong>Teléfono Móvil: </strong><?php echo e(Auth::user()->mobile); ?></p>
                                                <p><strong>Sexo: </strong> <?php if( Auth::user()->gender == 'm' ): ?> Masculino <?php else: ?> Femenino <?php endif; ?> </p>
                                                <hr>
                                            </div>
                                            <div class="col-md-6">
                                                <h3 class="mt-sm mb-xs"></h3>              
                                                <p><strong>Fecha de nacimiento: </strong><?php echo e(Auth::user()->birthday); ?></p>
                                                <p><strong>País: </strong><?php echo e(Auth::user()->country); ?></p> 
                                                <p><strong>Ciudad: </strong><?php echo e(Auth::user()->city); ?></p>
                                                <p><strong>Estado: </strong><?php echo e(Auth::user()->state); ?></p> 
                                                <p><strong>Dirección: </strong><?php echo e(Auth::user()->address); ?></p>
                                                <hr>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end panel -->
                </div>
                <div class="col-md-5">
                    <!-- begin panel -->
                    <div class="panel panel-inverse" data-sortable-id="table-basic-1">
                                <!-- begin panel-heading -->
                                <div class="panel-heading">
                                    
                                    <h4 class="panel-title">Cuentas bancarias
                                    </h4>
                                </div>
                                <!-- end panel-heading -->
                                <!-- begin panel-body -->
                                <div class="panel-body">
                                     <button class="btn btn-xs btn-inverse" onclick="openStoreAccountModal()"><i class="fa fa-plus"></i>Añadir cuenta</button>
                                        <!-- begin table-responsive -->
                                        <div class="table-responsive">
                                                <table class="table table-striped m-b-0">
                                                    <thead>
                                                    <tr>
                                                        <th>Banco</th>
                                                        <th>Número de Cuenta</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php $__currentLoopData = $bank_accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank_account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($bank_account->name); ?></td>
                                                        <td><?php echo e($bank_account->number); ?></td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                        </div>
                                        <!-- end table-responsive -->
                                </div>              
                    </div>

                    <div class="panel panel-inverse" data-sortable-id="table-basic-1">
                                <!-- begin panel-heading -->
                                <div class="panel-heading">
                                    
                                    <h4 class="panel-title">Wallet bitcoin
                                    </h4>
                                </div>
                                <!-- end panel-heading -->
                                <!-- begin panel-body -->
                                <div class="panel-body">
                                    <?php if(count(Auth::user()->wallets)<1): ?>
                                        <button class="btn btn-xs btn-inverse" onclick="openStoreWalletModal()"><i class="fa fa-plus"></i>Añadir wallet</button>
                                    <?php endif; ?>
                                        <!-- begin table-responsive -->
                                        <div class="table-responsive">
                                                <table class="table table-striped m-b-0">
                                                    <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Número de Wallet</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    
                                                    <?php $__currentLoopData = Auth::user()->wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($wallet->id_wallet); ?></td>
                                                            <td><?php echo e($wallet->label); ?> <?php echo e($wallet->address); ?></td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                                    </tbody>
                                                </table>
                                        </div>
                                        <!-- end table-responsive -->
                                </div>              
                    </div>
                </div>
            <!-- begin panel -->
            <div class="panel panel-inverse" style="width: 100%">
                <div class="panel-heading">
                    
                    <h4 class="panel-title">Completar perfil de usuario</h4>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-12">
                            <form id="user-form" method="post" data-parsley-priority-enabled="false" type='POST' action="<?php echo e(route('editUser',['id'=>Auth::user()->id])); ?>">
                                <?php echo e(csrf_field()); ?>

                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="username" class="control-label">Usuario</label>
                                                    <input type="text" name="username"  class="form-control" placeholder="Introduce tu usuario" value="<?php echo e(Auth::user()->user); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label for="name" class="control-label">Teléfono Movil</label>
                                                    <input type="mobile" name="mobile"  class="form-control" placeholder="Introduce tu teléfono movil" value="<?php echo e(Auth::user()->mobile); ?>">
                                                </div>
                                                
                                                <div class="form-group">
                                                    <div class="form-group">
                                                        <label for="expiration-date" class="control-label">Fecha de nacimiento</label>
                                                        
                                                            <div class="input-group date" id="datetimepicker1" style="width: 100%">
                                                                <input type="date" name="birthday" class="form-control" value="<?php echo e(Auth::user()->birthday); ?>">
                                                                <div class="input-group-addon">
                                                                    <i class="fa fa-calendar"></i>
                                                                </div>
                                                            </div>
                                                        
                                                    </div>
                                                    
                                                </div>
                                                <div class="form-group">
                                                    <!-- Password -->
                                                    <label class="control-label" for="sex">Sexo</label>
                                                    <br>
                                                    <div id="gender" class="btn-group" data-toggle="buttons">
                                                        <label class="btn btn-default " data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                                                        <input type="radio" name="gender" id="m" value="m" <?php if( Auth::user()->gender == 'm' ): ?>checked <?php endif; ?>> &nbsp; Masculino &nbsp;
                                                        </label>
                                                                <label class="btn btn-primary" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                                                                    <input type="radio" name="gender" id="f" value="f" <?php if( Auth::user()->gender == 'f' ): ?>checked <?php endif; ?>> Femenino
                                                                </label>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label"  for="identification">Documento de identificación</label>
                                                    <input type="file" id="identification" name="identification" class="">
                                                </div>

                                    </div>
                                    <div class="col-md-4">            
                                        
                                                <div class="form-group">
                                                    <label for="country" class="control-label">País</label>
                                                    <select id="country" name="country" class="form-control">
                                                    <option value=""></option>
                                                    <option value="Venezuela" selected>Venezuela</option>
                                                    </select>
                                                </div>
                                                <div class="form-group ">
                                                    <label class="control-label" for="city">Ciudad</label>
                                                    <input id="city" name="city" type="text" tabindex="3" class="form-control" placeholder="Introduce tu ciudad" value="<?php echo e(Auth::user()->city); ?>">
                                                </div>
                                                
                                                <div class="form-group">
                                                    <label for="state" class="control-label">Estado</label>
                                                    <input type="text" id="state" name="state" class="form-control" placeholder="Introduce tu estado" value="<?php echo e(Auth::user()->state); ?>">
                                                </div>
                                                    
                                                
                                                <div class="form-group">
                                                    <label class="control-label"  for="address">Dirección</label>
                                                    <input type="text" id="address" name="address" class="form-control" placeholder="Introduce tu dirección" value="<?php echo e(Auth::user()->address); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-label"  for="passport">Fotografía del pasaporte</label>
                                                    <input type="file" id="passport" name="passport" class="">
                                                </div>
                                                
                                        <hr>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="control-label"  for="address">Nombre</label>
                                            <input type="text" id="name" name="name" placeholder="" class="form-control" value="<?php echo e(Auth::user()->name); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label"  for="address">Apellido</label>
                                            <input type="text" id="lastname" name="lastname" placeholder="" class="form-control" value="<?php echo e(Auth::user()->lastname); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label"  for="address">E-mail</label>
                                            <input type="text" id="email" name="email" placeholder="" class="form-control" value="<?php echo e(Auth::user()->email); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label"  for="phone">Teléfono local</label>
                                            <input type="text" id="phone" name="phone" placeholder="" class="form-control" value="<?php echo e(Auth::user()->phone); ?>">
                                        </div>
                                        <button type="submit" class="btn btn-success">Actualizar Perfil</button>
                                        
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end panel -->
        </div>
        <!-- end #content -->
<?php echo $__env->make('bankAccounts.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('wallet.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('footer_section'); ?>
    <script src="<?php echo e(asset('js/bankaccount/store.js')); ?>"></script>
    <script src="<?php echo e(asset('js/wallet/store.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>