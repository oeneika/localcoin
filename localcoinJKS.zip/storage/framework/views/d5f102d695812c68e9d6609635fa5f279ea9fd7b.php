<?php $__env->startSection('content'); ?>
<!-- begin #content -->
<div id="content" class="content">
            <!-- begin breadcrumb -->
            <ol class="breadcrumb pull-right">
                <li class="breadcrumb-item"><a href="javascript:;">Inicio</a></li>
                <li class="breadcrumb-item active">Usuarios</li>
            </ol>

            <!-- end breadcrumb -->
            <!-- begin page-header -->
            <h1 class="page-header">Listado de usuarios</h1>
            <!-- end page-header -->   

            
            <!-- begin panel -->
            <div class="panel panel-inverse" data-sortable-id="table-basic-4">
                        <!-- begin panel-heading -->
                        <div class="panel-heading">
                            
                            <h4 class="panel-title">Usuarios</h4>
                        </div>
                        <!-- end panel-heading -->

                        <!-- begin panel-body -->
                        <div class="panel-body">
                            <!-- begin table-responsive -->
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Nombre</th>
                                            <th>Apellido</th>
                                            <th>No. Transacciones</th>
                                            <th>Puntuación</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($user->id); ?></td>
                                                <td><?php echo e($user->name); ?></td>
                                                <td><?php echo e($user->lastname); ?></td>
                                                <td><?php echo e($user->transactions_by_user); ?></td>
                                                <td><?php echo e($user->rank); ?> <i class="fa fa-star amarillito"></i></td>
                                                <td><button type="button" class="btn btn-primary" onclick="showRankModal(<?php echo e($user->id); ?>,<?php echo e($user->rank); ?>)" data-toggle="modal" data-target="#puntuarModal">Puntuar</button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            <!-- end table-responsive -->
                        </div>
                        <!-- end panel-body -->
            </div>
            <!-- end panel -->        
</div>
<!-- end #content -->
<?php echo $__env->make('users.rank', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_section'); ?>
    <script src="<?php echo e(asset('js/users/rank.js')); ?>"></script>
    <script>
// Using vanilla javascript:
var starrating = new StarRating( document.getElementById( 'star-rating' ));
// OR - Using jQuery:
$( '#star-rating' ).starrating();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>