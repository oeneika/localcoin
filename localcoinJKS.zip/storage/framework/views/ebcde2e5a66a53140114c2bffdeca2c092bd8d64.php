<?php $__env->startSection('content'); ?>
<!-- begin #content -->
<div id="content" class="content">
            <!-- begin breadcrumb -->
            <ol class="breadcrumb pull-right">
                <li class="breadcrumb-item"><a href="javascript:;">Inicio</a></li>
                <li class="breadcrumb-item active">Transacciones - Mis Ventas</li>
            </ol>

            <!-- end breadcrumb -->
            <!-- begin page-header -->
            <h1 class="page-header">Transacciones - Mis Ventas</h1>
            <!-- end page-header -->   

            <div class="row">
                <div class="col-md-12">
                <button <?php if(count(Auth::user()->wallets) < 1): ?> disabled <?php endif; ?> class="btn btn-primary" style="float:right; margin-bottom: 10px;" onclick="openModalSell()"> Crear Venta </button>
                </div>
            </div>

            
            <!-- begin panel -->
            <div class="panel panel-inverse" data-sortable-id="table-basic-4">
                        <!-- begin panel-heading -->
                        <div class="panel-heading">
                            
                            <h4 class="panel-title">Transacciones</h4>
                        </div>
                        <!-- end panel-heading -->

                        <!-- begin panel-body -->
                        <div class="panel-body">
                            <!-- begin table-responsive -->
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Cantidad</th>
                                            <th>Moneda</th>
                                            <th>Estatus</th>
                                            <th>Fecha de Creación</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($transaction->id_transaction); ?></td>
                                            <td><?php echo e(number_format($transaction->price,2,',','.')); ?></td>
                                            <td><?php echo e($transaction->name); ?></td>
                                            <?php if($transaction->status == 0): ?>
                                                <td><span class="label label-success">Abierta</span></td>
                                            <?php elseif($transaction->status == 1): ?>
                                                <td><span class="label label-info">Pendiente</span></td>
                                            <?php else: ?>
                                                <td><span class="label label-danger">Procesada</span></td>
                                            <?php endif; ?>
                                            <td><?php echo e(date('m/d/Y', date_timestamp_get($transaction->created_at))); ?></td>
                                            
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- end table-responsive -->
                        </div>
                        <!-- end panel-body -->
            </div>
            <!-- end panel -->        
</div>
<!-- end #content -->
<?php echo $__env->make('transactions.submitsell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('transactions.editsell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_section'); ?>
    <script src="<?php echo e(asset('js/transaction/storesell.js')); ?>"></script>
    <script src="<?php echo e(asset('js/transaction/updatesell.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>