<?php $__env->startSection('content'); ?>
<!-- begin #content -->
    <div id="content" class="content">
            <!-- begin breadcrumb -->
            <ol class="breadcrumb pull-right">
                <li class="breadcrumb-item"><a href="javascript:;">Inicio</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
            <!-- end breadcrumb -->
            <!-- begin page-header -->
            <h1 class="page-header">Dashboard</h1>
            <!-- end page-header -->   

            <!-- begin row -->
            <div class="row">
                <!-- begin col-12 -->
                <div class="col-md-12">
                    <!-- begin panel -->
                    <div class="panel panel-inverse" data-sortable-id="chart-js-1">
                        <div class="panel-heading">
                            
                            <h4 class="panel-title">Bitcoin</h4>
                        </div>
                        <div class="panel-body">
                            <p>
                                Bitcoin. Gráfica en tiempo real
                            </p>
                            <div>
                                <canvas id="line-chart" data-render="chart-js" height="80"></canvas>
                            </div>
                        </div>
                    </div>
                    <!-- end panel -->
                </div>
                <!-- end col-12 -->
            </div>
            <!-- end row -->
            
            <!-- begin panel -->
            <div class="panel panel-inverse" data-sortable-id="table-basic-4">
                        <!-- begin panel-heading -->
                        <div class="panel-heading">
                            
                            <h4 class="panel-title">Vender</h4>
                        </div>
                        <!-- end panel-heading -->

                        <!-- begin panel-body -->
                        <div class="panel-body">
                            <!-- begin table-responsive -->
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Reputación del Usuario</th>
                                        <th>Precio</th>
                                        <th>Cantidad</th>
                                        <th>Acción</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $buys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php if($buy->status == 2): ?>
                                                    <?php continue; ?>
                                                <?php endif; ?>
                                                <tr>
                                                    <td><?php echo e($buy->id_transaction); ?></td>
                                                    <td><?php for($i = 0; $i < $buy->reputation; $i++): ?> <i class="fa fa-star amarillito"></i> <?php endfor; ?></td>
                                                    <td><?php echo e($buy->price); ?></td>
                                                    <td><?php echo e($buy->quantity); ?></td>
                                                    <?php if(Auth::user()->id != $buy->id): ?>
                                                        <td><button <?php if(count(Auth::user()->wallets) < 1): ?> disabled <?php endif; ?> type="button" onclick="showDetailsModal('<?php echo e($buy->name); ?>','<?php echo e($buy->lastname); ?>','<?php echo e($buy->phone); ?>','<?php echo e($buy->mobile); ?>','<?php echo e($buy->bank_name); ?>',<?php echo e($buy->price); ?>,<?php echo e($buy->quantity); ?>,'<?php echo e($buy->email); ?>',<?php echo e($buy->id_transaction); ?>)" class="btn btn-primary" on>Vender</button></td>
                                                    <?php endif; ?>
                                                </tr>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- end table-responsive -->
                        </div>
                        <!-- end panel-body -->
            </div>
            <!-- end panel -->
            
            <!-- begin panel -->
            <div class="panel panel-inverse" data-sortable-id="table-basic-4">
                        <!-- begin panel-heading -->
                        <div class="panel-heading">
                           
                            <h4 class="panel-title">Comprar</h4>
                        </div>
                        <!-- end panel-heading -->

                        <!-- begin panel-body -->
                        <div class="panel-body">
                            <!-- begin table-responsive -->
                            <div class="table-responsive">
                                <table class="table">
                                   <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Reputación del Usuario</th>
                                            <th>Precio</th>
                                            <th>Cantidad</th>
                                            <th>Acción</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <?php $__currentLoopData = $sells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($sell->status == 2): ?>
                                                    <?php continue; ?>
                                                <?php endif; ?>
                                                <tr>
                                                    <td><?php echo e($sell->id_transaction); ?></td>
                                                    <td><?php for($i = 0; $i < $sell->reputation; $i++): ?> <i class="fa fa-star amarillito"></i> <?php endfor; ?></td>
                                                    <td><?php echo e($sell->price); ?></td>
                                                    <td><?php echo e($sell->quantity); ?></td>
                                                    <?php if(Auth::user()->id != $sell->id): ?>
                                                        <td><button <?php if(count(Auth::user()->wallets) < 1): ?> disabled <?php endif; ?> type="button" onclick="showDetailsModal('<?php echo e($sell->name); ?>','<?php echo e($sell->lastname); ?>','<?php echo e($sell->phone); ?>','<?php echo e($sell->mobile); ?>','<?php echo e($sell->bank_name); ?>',<?php echo e($sell->price); ?>,<?php echo e($sell->quantity); ?>,'<?php echo e($sell->email); ?>',<?php echo e($sell->id_transaction); ?>)" class="btn btn-primary" on>Comprar</button></td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                        </tbody>
                                </table>
                            </div>
                            <!-- end table-responsive -->
                        </div>
                        <!-- end panel-body -->
            </div>
            <!-- end panel -->
    </div>
<!-- end #content -->
<?php echo $__env->make('transactions.buy', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_section'); ?>
    <script src="<?php echo e(asset('js/transaction/buy.js')); ?>"></script>
    <script src="<?php echo e(asset('js/home/homelinechart.js')); ?>"></script>
    <script>
        $('.fechalacra input').datepicker({
                format: "dd/mm/yyyy",
                todayBtn: "linked",
                language: "es",
                autoclose: true,
                todayHighlight: true
            });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>