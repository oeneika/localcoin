<?php $__env->startSection('content'); ?>
<!-- begin #content -->
<div id="content" class="content">
            <!-- begin breadcrumb -->
            <ol class="breadcrumb pull-right">
                <li class="breadcrumb-item"><a href="javascript:;">Inicio</a></li>
                <li class="breadcrumb-item active">Transacciones realizadas</li>
            </ol>
            <!-- end breadcrumb -->
            <!-- begin page-header -->
            <h1 class="page-header">Transacciones Realizadas</h1>
            <!-- end page-header -->   
            
            <!-- begin panel -->
            <div class="panel panel-inverse" data-sortable-id="table-basic-4">
                        <!-- begin panel-heading -->
                        <div class="panel-heading">
                            
                            <h4 class="panel-title">Transacciones</h4>
                        </div>
                        <!-- end panel-heading -->

                        <!-- begin panel-body -->
                        <div class="panel-body">
                            <!-- begin table-responsive -->
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Cantidad</th>
                                            <th>Precio</th>
                                            <th>Moneda</th>
                                            <th>Usuario</th>
                                            <th>Cuenta de Corpbinary</th>
                                            <th>Fecha de Realización</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <?php if($transaction->type == 0): ?>
                                                <td><span class="label label-warning">Compra <?php echo e($transaction->id_transaction); ?></span></td>
                                            <?php else: ?>
                                                <td><span class="label label-danger">Venta <?php echo e($transaction->id_transaction); ?></span></td>
                                            <?php endif; ?>
                                            <td><?php echo e($transaction->quantity); ?></td>
                                            <td><?php echo e(number_format($transaction->price,2,',','.')); ?></td>
                                            <td><?php echo e($transaction->currency_name); ?></td>
                                            <td><?php echo e($transaction->name); ?> <?php echo e($transaction->lastname); ?> - <?php echo e($transaction->user); ?></td>
                                            <td>72839182738492810</td>
                                            <td><?php echo e(date('m/d/Y', date_timestamp_get($transaction->updated_at))); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                </table>
                            </div>
                            <!-- end table-responsive -->
                        </div>
                        <!-- end panel-body -->
            </div>
            <!-- end panel -->        
</div>
<!-- end #content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>