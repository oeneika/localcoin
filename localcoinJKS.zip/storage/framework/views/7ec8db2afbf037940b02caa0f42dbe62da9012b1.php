<?php $__env->startSection('content'); ?>
<!-- begin #content -->
<div id="content" class="content">
            <!-- begin breadcrumb -->
            <ol class="breadcrumb pull-right">
                <li class="breadcrumb-item"><a href="javascript:;">Inicio</a></li>
                <li class="breadcrumb-item active">Transacciones en espera</li>
            </ol>

            <!-- end breadcrumb -->
            <!-- begin page-header -->
            <h1 class="page-header">Transacciones en espera</h1>
            <!-- end page-header -->   

            
            <!-- begin panel -->
            <div class="panel panel-inverse" data-sortable-id="table-basic-4">
                        <!-- begin panel-heading -->
                        <div class="panel-heading">
                            
                            <h4 class="panel-title">Transacciones</h4>
                        </div>
                        <!-- end panel-heading -->

                        <!-- begin panel-body -->
                        <div class="panel-body">
                            <!-- begin table-responsive -->
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Vendedor</th>
                                            <th>Comprador</th>
                                            <th>Fecha</th>
                                            <th>Cantidad</th>
                                            <th>Precio</th>
                                            <th>Cuentas</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                
                                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($transaction->id_transaction); ?></td>
                                                <?php if($transaction->type == 1): ?>
                                                    <td><?php echo e($transaction->sub_name); ?> <?php echo e($transaction->sub_lastname); ?></td>
                                                    <td><?php echo e($transaction->rec_name); ?> <?php echo e($transaction->rec_lastname); ?></td>
                                                <?php else: ?>
                                                    <td><?php echo e($transaction->rec_name); ?> <?php echo e($transaction->rec_lastname); ?></td>
                                                    <td><?php echo e($transaction->sub_name); ?> <?php echo e($transaction->sub_lastname); ?></td>
                                                <?php endif; ?>
                                                <td><?php echo e(date('m/d/Y', date_timestamp_get($transaction->updated_at))); ?></td>
                                                <td><?php echo e($transaction->quantity); ?></td>
                                                <td><?php echo e($transaction->price); ?> <?php echo e($transaction->abv); ?></td>
                                                <td>
                                                    <button type="button" onclick="openAccountsModal(<?php echo e($transaction->type); ?>,'<?php echo e($transaction->sub_name); ?> <?php echo e($transaction->sub_lastname); ?>','<?php echo e($transaction->rec_name); ?> <?php echo e($transaction->rec_lastname); ?>','<?php echo e($transaction->submitting_number); ?>','<?php echo e($transaction->receiving_number); ?>','<?php echo e($transaction->sub_address); ?>','<?php echo e($transaction->rec_address); ?>',<?php echo e($transaction->submitting_transfer_number); ?>,<?php echo e($transaction->receiving_transfer_number); ?>)" class="btn btn-primary"><i class="fa fa-eye text-navy"></i> Ver cuentas</button>
                                                </td>
                                                <td>
                                                    <button type="button" onclick='approve( "<?php echo e(route('approveTransaction',$transaction->id_transaction)); ?>","<?php echo e(csrf_token()); ?>" )' class="btn btn-primary" ><i class="fa fa-check text-navy"> </i> Aprobar Transacción</button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            <!-- end table-responsive -->
                        </div>
                        <!-- end panel-body -->
            </div>
            <!-- end panel -->        
</div>
<!-- end #content -->
<?php echo $__env->make('transactions.accounts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_section'); ?>
    <script src="<?php echo e(asset('js/transaction/approve.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>