<footer class="content-footer">
   Corpbinary Panel - Hecho por <a href="https://corporacionjsk.com" rel="nofollow noopener noreferrer" target="_blank">Corporacion JSK</a>
</footer>