<?php if(Auth::user()): ?>
    <?php if(count(Auth::user()->BankAccounts) < 1): ?>
            <div class="alert alert-danger">
                <p>
                    En estos momentos no tiene una cuenta de banco asociada. 
                    Para asociar una, por favor digirse a su perfil de usuario.
                </p>
            </div>
    <?php endif; ?>
<?php endif; ?>
<?php if(count($errors)>0): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger">
                <?php echo e($error); ?>

            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>