<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>CorpBinary</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!-- Styles -->
    
    <link href="<?php echo e(asset('css/application.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/estilos.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">
        <?php echo $__env->make('inc.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- common libraries. required for every page-->
<script src="<?php echo e(asset('lib/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/jquery-pjax/jquery.pjax.js')); ?>"></script>
<script src="<?php echo e(asset('lib/bootstrap-sass/assets/javascripts/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/widgster/widgster.js')); ?>"></script>
<script src="<?php echo e(asset('lib/underscore/underscore.js')); ?>"></script>

<!-- common application js -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/settings.js')); ?>"></script>


    <!-- page specific scripts -->
    <!-- page libs -->
        <script src="<?php echo e(asset('lib/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
        <script src="<?php echo e(asset('lib/select2/select2.min.js')); ?>"></script>
        <script src="<?php echo e(asset('lib/jquery.maskedinput/dist/jquery.maskedinput.min.js')); ?>"></script>
        <script src="<?php echo e(asset('lib/moment/moment.js')); ?>"></script>
        <script src="<?php echo e(asset('lib/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js')); ?>"></script>
        <script src="<?php echo e(asset('lib/twitter-bootstrap-wizard/jquery.bootstrap.wizard.min.js')); ?>"></script>

        <!-- page application js -->
        <script src="<?php echo e(asset('js/forms-wizard.js')); ?>"></script>
</body>
</html>
