<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>CorpBinary</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!-- Toastr -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.css" rel="stylesheet"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css" rel="stylesheet"/>

    <!-- Styles -->
    
    <link href="<?php echo e(asset('css/application.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/estilos.css')); ?>" rel="stylesheet">
</head>
<body>
        <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="wrap">
            <?php echo $__env->make('inc.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        

    <!-- common libraries. required for every page-->
<script src="<?php echo e(asset('lib/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/jquery-pjax/jquery.pjax.js')); ?>"></script>
<script src="<?php echo e(asset('lib/bootstrap-sass/assets/javascripts/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('lib/widgster/widgster.js')); ?>"></script>
<script src="<?php echo e(asset('lib/underscore/underscore.js')); ?>"></script>
<script src="<?php echo e(asset('js/php.js')); ?>"></script>

<!-- common application js -->
<script src="<?php echo e(asset('js/settings.js')); ?>"></script>


    <!-- page specific scripts -->
        <!-- page libs -->
        <script src="<?php echo e(asset('lib/slimScroll/jquery.slimscroll.min.js')); ?>"></script>
        <script src="<?php echo e(asset('lib/jquery.sparkline/index.js')); ?>"></script>

        <script src="<?php echo e(asset('lib/backbone/backbone.js')); ?>"></script>
        <script src="<?php echo e(asset('lib/backbone.localStorage/backbone.localStorage-min.js')); ?>"></script>

        <script src="<?php echo e(asset('lib/d3/d3.min.js')); ?>"></script>
        <script src="<?php echo e(asset('lib/nvd3/build/nv.d3.min.js')); ?>"></script>

        <script src="<?php echo e(asset('js/chartjs-demo.js')); ?>"></script>
        <script src="<?php echo e(asset('js/chart.min.js')); ?>"></script>

        <!-- page application js -->
        <script src="<?php echo e(asset('js/chat.js')); ?>"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.js.map"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>

        <!-- SweetAlert -->
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

        <script src="<?php echo e(asset('js/delete_item.js')); ?>"></script>

        <!-- important routes -->
        <script>
                var url = {
                    storeSell:              '<?php echo e(route('storeSell')); ?>',
                    storeBuy:               '<?php echo e(route('storeBuy')); ?>',
                    updateBuy:              '<?php echo e(route('updateBuy')); ?>',
                    updateSell:             '<?php echo e(route('updateSell')); ?>',
                    makeTransaction:        '<?php echo e(route('makeTransaction')); ?>',
                    storeBankAccount:       '<?php echo e(route('storeBankAccount')); ?>'}
        </script>
        <!-- Page specific scripts -->
        <?php echo $__env->yieldContent('footer_section'); ?>
</body>
</html>
