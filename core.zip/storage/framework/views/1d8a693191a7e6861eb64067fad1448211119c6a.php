<?php $__env->startSection('content'); ?>
<div class="content container">
        <h2 class="page-title">Dashboard <small>Estadisticas y datos más relevantes</small></h2>
        <div class="row">
            <div class="col-lg-12">
                <section class="widget">
                    <header>
                        <h4>
                            Bitcoin
                            <small>
                                Grafica en tiempo real
                            </small>
                        </h4>
                        <div class="widget-controls">
                            <a data-widgster="close" title="Close" href="#"><i class="glyphicon glyphicon-remove"></i></a>
                        </div>
                    </header>
                    
                    <div class="ibox ">
                        <div class="ibox-content">
                            <div>
                                <canvas id="lineChart" height="70"></canvas>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="widget">
                    <header>
                        <h4>
                            Ventas
                        </h4>
                        <div class="widget-controls">
                            <a data-widgster="expand" title="Expand" href="#"><i class="glyphicon glyphicon-plus"></i></a>
                            <a data-widgster="collapse" title="Collapse" href="#"><i class="glyphicon glyphicon-minus"></i></a>
                            <a data-widgster="close" title="Close" href="#"><i class="glyphicon glyphicon-remove"></i></a>
                        </div>
                    </header>
                        <div class="widget-table-overflow">
                            <table class="table table-striped">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Vendedor</th>
                                        <th>User</th>
                                        <th>Price</th>
                                        <th>Cantidad</th>
                                        <th>Acción</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <?php $__currentLoopData = $sells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($sell->status == 2): ?>
                                                <?php continue; ?>
                                            <?php endif; ?>
                                            <tr>
                                                <td><?php echo e($sell->id_transaction); ?></td>
                                                <td><?php echo e($sell->name); ?> <?php echo e($sell->lastname); ?></td>
                                                <td><?php echo e($sell->user); ?></td>
                                                <td><?php echo e($sell->price); ?></td>
                                                <td><?php echo e($sell->quantity); ?></td>
                                                <?php if(Auth::user()->id != $sell->id): ?>
                                                    <td><button type="button" onclick="showDetailsModal('<?php echo e($sell->name); ?>','<?php echo e($sell->lastname); ?>','<?php echo e($sell->phone); ?>','<?php echo e($sell->mobile); ?>','<?php echo e($sell->bank_name); ?>',<?php echo e($sell->price); ?>,<?php echo e($sell->quantity); ?>,'<?php echo e($sell->email); ?>',<?php echo e($sell->id_transaction); ?>)" class="btn btn-primary" on>Comprar</button></td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    </tbody>
                                </table>
                        </div>
                </section>
                <section class="widget">
                    <header>
                    <h4>
                        Compras
                    </h4>
                    <div class="widget-controls">
                        <a data-widgster="expand" title="Expand" href="#"><i class="glyphicon glyphicon-plus"></i></a>
                        <a data-widgster="collapse" title="Collapse" href="#"><i class="glyphicon glyphicon-minus"></i></a>
                            <a data-widgster="close" title="Close" href="#"><i class="glyphicon glyphicon-remove"></i></a>
                        </div>
                    </header>
                    <div class="widget-table-overflow">
                        <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Comprador</th>
                                    <th>User</th>
                                    <th>Price</th>
                                    <th>Cantidad</th>
                                    <th>Acción</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $buys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <?php if($buy->status == 2): ?>
                                                <?php continue; ?>
                                            <?php endif; ?>
                                            <tr>
                                                <td><?php echo e($buy->id_transaction); ?></td>
                                                <td><?php echo e($buy->name); ?> <?php echo e($buy->lastname); ?></td>
                                                <td><?php echo e($buy->user); ?></td>
                                                <td><?php echo e($buy->price); ?></td>
                                                <td><?php echo e($buy->quantity); ?></td>
                                                <?php if(Auth::user()->id != $buy->id): ?>
                                                    <td><button type="button" onclick="showDetailsModal('<?php echo e($buy->name); ?>','<?php echo e($buy->lastname); ?>','<?php echo e($buy->phone); ?>','<?php echo e($buy->mobile); ?>','<?php echo e($buy->bank_name); ?>',<?php echo e($buy->price); ?>,<?php echo e($buy->quantity); ?>,'<?php echo e($buy->email); ?>',<?php echo e($buy->id_transaction); ?>)" class="btn btn-primary" on>Vender</button></td>
                                                <?php endif; ?>
                                            </tr>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                    </div>
                </section>
                
            </div>
        </div>
            <?php echo $__env->make('transactions.buy', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="loader-wrap hiding hide">
            <i class="fa fa-circle-o-notch fa-spin"></i>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_section'); ?>
    <script src="<?php echo e(asset('js/transaction/buy.js')); ?>"></script>
    <script src="<?php echo e(asset('js/home/homelinechart.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>