<?php $__env->startSection('content'); ?>
<div class="single-widget-container">
            <section class="widget login-widget">
                <header class="text-align-center">
                    <h4>Inicio de sesión</h4>
                </header>
                <div class="body">
                    <form class="no-margin" method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                        <?php echo csrf_field(); ?>
                        <fieldset>
                            <div class="form-group">
                                <label for="email" >Email</label>
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-user"></i>
                                    </span>
                                    <input id="email" name="email" type="email" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?> input-lg input-transparent" placeholder="Tu Email" value="<?php echo e(old('email')); ?>" required autofocus>
                                    <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="password" >Contraseña</label>

                                <div class="input-group input-group-lg">
                                    <span class="input-group-addon">
                                        <i class="fa fa-lock"></i>
                                    </span>
                                    <input id="password" name="password" type="password" class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?> input-lg input-transparent"
                                           placeholder="Tu contraseña">
                                           <?php if($errors->has('password')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                </div>
                            </div>
                        </fieldset>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-block btn-lg btn-danger">
                                <small><?php echo e(__('Iniciar Sesión')); ?></small>
                            </button>
                            <a class="forgot" href="<?php echo e(route('password.request')); ?>"><?php echo e(__('¿Olvidaste tu contraseña?')); ?></a>
                        </div>
                    </form>
                </div>
                <footer>
                    <div class="facebook-login">
                        <a href="<?php echo e(route('register')); ?>">¿Aún no estás registrado? <strong>¡Registrate!</strong></a>
                    </div>
                </footer>
            </section>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>