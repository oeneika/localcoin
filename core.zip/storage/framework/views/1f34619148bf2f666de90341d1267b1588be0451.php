<?php $__env->startSection('content'); ?>
<div class="content container">
    <h2 class="page-title">
            Transacciones - <span class="fw-semi-bold">Mis Ventas</span>
    </h2>
    <div class="row">
        <div class="col-md-12">
            <button class="btn btn-primary" style="float:right; margin-bottom: 10px;" onclick="openModalBuy()"> Crear Venta </button>
        </div>
    </div>
    <section class="widget">
        <header>
            <h4>
                Ventas
            </h4>
            <div class="widget-controls">
                <a data-widgster="expand" title="Expand" href="#"><i class="glyphicon glyphicon-plus"></i></a>
                <a data-widgster="collapse" title="Collapse" href="#"><i class="glyphicon glyphicon-minus"></i></a>
            </div>
        </header>
            <div class="widget-table-overflow">
                <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Cantidad</th>
                            <th>Moneda</th>
                            <th>Estatus</th>
                            <th>Fecha de Creación</th>
                            <th>Acciones</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($transaction->id_transaction); ?></td>
                            <td><?php echo e(number_format($transaction->price,2,',','.')); ?></td>
                            <td><?php echo e($transaction->name); ?></td>
                            <?php if($transaction->status = 0): ?>
                                <td><span class="label label-primary">Abierta</span></td>
                            <?php elseif($transaction->status = 1): ?>
                                <td><span class="label label-info">Pendiente</span></td>
                            <?php else: ?>
                                <td><span class="label label-danger">Procesada</span></td>
                            <?php endif; ?>
                            <td><?php echo e(date('m/d/Y', date_timestamp_get($transaction->created_at))); ?></td>
                            <td>
                                <a class="btn btn-info" onclick="openModalEditBuy(<?php echo e($transaction->id_transaction); ?>,<?php echo e($transaction->price); ?>,<?php echo e($transaction->id_currency); ?>,<?php echo e($transaction->id_submitting_account); ?>,<?php echo e($transaction->quantity); ?>)"><i class="fa fa-sliders"></i></a>
                                <a class="btn btn-danger" onclick="delete_item('<?php echo e(route('deleteTransaction',['id'=>$transaction->id_transaction])); ?>','<?php echo e(csrf_token()); ?>')"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
            </div>
    </section>
</div>
<?php echo $__env->make('transactions.submitbuy', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('transactions.editbuy', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
        <div class="loader-wrap hiding hide">
            <i class="fa fa-circle-o-notch fa-spin"></i>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_section'); ?>
    <script src="<?php echo e(asset('js/transaction/storebuy.js')); ?>"></script>
    <script src="<?php echo e(asset('js/transaction/updatebuy.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>